function [mot_pos3 ]=Inverse_kinematic(ee_position)
% ee_position为末端坐标，此处要求传入末端在腿坐标系的位置，按顺序为xyz
% mot_pos即为驱动杆件的坐标变化值,按顺序为x,y,Rotation
%竖直转动轴
mot_pos3(3)=atan2(ee_position(3),-ee_position(1));%此处暂时加负号，方便理解,记录的是角度
x=sqrt(ee_position(3)^2+ee_position(1)^2);
y=ee_position(2);
%末端位置x,y
%固定杆长
AC = 185;
CD = 100;
AG = 100;
DE = 155;
EN = 220;
DG = 185;
GF = 60;
GH = 020;
AJ = 90.5;
LM = 20;
BF = 120;
%固定角度
%x向初始位置
H_0x = 25.5;
%y向初始位置,即P点比A点在y方向高出的长度
B_0y = 45;


NC = CD + DE +EN;
AN = sqrt(x^2+y^2);
angle_NCA = (acos((NC^2+AC^2-AN^2)/2/NC/AC));
angle_CAN = (acos((AC^2+AN^2-NC^2)/2/AC/AN));
angle_CAG = pi - angle_NCA;
angle_NAG = angle_CAG-angle_CAN;
angle_NAJ = (atan(-x/y));
angle_GAJ = angle_NAJ - angle_NAG;
Gx = AG*sin(angle_GAJ);
Gy = -AG*cos(angle_GAJ);
vector_AG = [Gx  Gy];
Hy =-AJ;
GK = Gy-Hy;
angle_GHK=asin(GK/GH);
HK = GH*cos(angle_GHK);
Hx = Gx-HK;
mot_pos3(1) = Hx-H_0x;%X推杆变化距离

vector_AN = [x y];
vector_CN = NC/AG*vector_AG;
vector_AC = vector_AN-vector_CN;
vector_GF = GF/AC*vector_AC;
vector_AF = vector_AG+vector_GF;
m=vector_AF(1);
n=vector_AF(2);
FL = m-LM;
BL = sqrt(BF^2-FL^2);
By = n+BL;
mot_pos3(2) = By-B_0y;%Y推杆变化距离
%此处打印的是腿坐标系下的位置
%fprintf('the ee_position is (zxy)[%8.8f  %8.8f,  %8.8f],the mot_pos3 is (rxy)[%8.8f  %8.8f,  %8.8f]\n',ee_position(1),ee_position(2),ee_position(3),mot_pos3(1),mot_pos3(2),mot_pos3(3));




