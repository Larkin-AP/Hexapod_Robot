#ifndef ROBOT_H_
#define ROBOT_H_

#include<memory>
#include<aris.hpp>

namespace robot
{
	class HexDynamicTest :public aris::core::CloneObject<HexDynamicTest, aris::plan::Plan> {
	public:
		auto virtual prepareNrt()->void;
		auto virtual executeRT()->int override;

		virtual ~HexDynamicTest();
		explicit HexDynamicTest() {}
		//explicit HexDynamicTest(const std::string& name = "dog_yaw");
	};


	auto createModelHexapod()->std::unique_ptr<aris::dynamic::Model>;
	auto createControllerHexapod()->std::unique_ptr<aris::control::Controller>;
	auto createPlanHexapod()->std::unique_ptr<aris::plan::PlanRoot>;
	auto setStandTopologyIK(aris::server::ControlServer& cs)->void;
}
#endif